module.exports = {
	SEARCH_TEXT: 'SEARCH_TEXT'
}