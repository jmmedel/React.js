var React = require('react');
var AppActions = require('../actions/AppActions');
var AppStore = require('../stores/AppStore');

var SearchResults = React.createClass({
	render: function(){
		return(
			<div>
				RESULTS
			</div>
		);
	},

});

module.exports = SearchResults;