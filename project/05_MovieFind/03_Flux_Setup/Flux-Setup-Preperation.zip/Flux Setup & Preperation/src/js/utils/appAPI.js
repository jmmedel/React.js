var AppActions = require('../actions/AppActions');

module.exports = {
	searchMovies: function(movie){

	}
}