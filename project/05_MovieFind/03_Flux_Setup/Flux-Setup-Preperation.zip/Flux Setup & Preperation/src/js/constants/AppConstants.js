module.exports = {
	SEARCH_MOVIES: 'SEARCH_MOVIES'
}