import React, {Component} from 'react';
import ReactDOM from 'react-dom';

class App extends Component{
	constructor(props){
		super(props);
		this.state = {

		}
	}

	render(){
		return(
			<div>
				This is my app
			</div>
		)
	}
}

export default App