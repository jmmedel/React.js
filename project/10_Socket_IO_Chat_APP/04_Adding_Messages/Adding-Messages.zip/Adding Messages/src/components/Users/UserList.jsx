import React, {Component} from 'react';
import ReactDOM from 'react-dom';

class UserList extends Component{
	render(){
		return(
			<div>
				USERLIST
			</div>
		)
	}
}

export default UserList