import React, {Component} from 'react';
import ReactDOM from 'react-dom';

class UserForm extends Component{
	render(){
		return(
			<div>
				USERFORM
			</div>
		)
	}
}

export default UserForm