module.exports = {
	RECEIVE_ITEMS: 'RECEIVE_ITEMS'
}