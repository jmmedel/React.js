module.exports = {
	SAVE_VIDEO: 'SAVE_VIDEO'
}