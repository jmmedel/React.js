module.exports = {
	ADD_NOTE: 'ADD_NOTE'
}