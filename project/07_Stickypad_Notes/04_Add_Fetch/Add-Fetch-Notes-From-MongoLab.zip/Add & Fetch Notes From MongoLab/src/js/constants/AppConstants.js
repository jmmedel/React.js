module.exports = {
	ADD_NOTE: 'ADD_NOTE',
	RECEIVE_NOTES: 'RECEIVE_NOTES'
}