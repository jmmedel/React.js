module.exports = {
	SHOW_FORM: 'SHOW_FORM',
	ADD_WORKOUT: 'ADD_WORKOUT'
}