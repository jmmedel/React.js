var React = require('react');
var AppActions = require('../actions/AppActions');
var AppStore = require('../stores/AppStore');

var AddForm = React.createClass({
	render: function(){
		return(
			<div>
			FORM
			</div>
		);
	}
	
});

module.exports = AddForm;